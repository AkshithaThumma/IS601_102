#Name :Akshitha Thumma
##UCID: AT892@njit.edu  Date of submission:02-11-2023
function hideAbout() {
  document.getElementById("about").style.display = "none";
  document.getElementById("show-button").style.display = "inline";
  document.getElementById("hide-button").style.display = "none";
}

function showAbout() {
  document.getElementById("about").style.display = "block";
  document.getElementById("show-button").style.display = "none";
  document.getElementById("hide-button").style.display = "inline";
}

function validateForm() {
  let subject = document.getElementById("subject").value;
  let firstName = document.getElementById("first-name").value;
  let lastName = document.getElementById("last-name").value;
  let email = document.getElementById("email").value;
  let message = document.getElementById("message").value;
  let subjectError = document.getElementById("subject-error");
  let firstNameError = document.getElementById("first-name-error");
  let lastNameError = document.getElementById("last-name-error");
  let emailError = document.getElementById("email-error");
  let messageError = document.getElementById("message-error");
  let valid = true;

  if (subject == "") {
    subjectError.style.display = "block";
    valid = false;
  } else {
    subjectError.style.display = "none";
  }

  if (firstName == "") {
    firstNameError.style.display = "block";
    valid = false;
  } else {
    firstNameError.style.display = "none";
  }

  if (lastName == "") {
    lastNameError.style.display = "block";
    valid = false;
  } else {
    lastNameError.style.display = "none";
  }

  if (email == "") {
    emailError.style.display = "block";
    valid = false;
  } else {
    emailError.style.display = "none";
  }

  if (message == "") {
    messageError.style.display = "block";
    valid = false;
  } else {
    messageError.style.display = "none";
  }

  return valid;
}
