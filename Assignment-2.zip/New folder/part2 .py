# UCID:at892
# Name: Akshitha Thumma
# Date of submission :02-26-2023  
class BankAccount:
    def __init__(self, account_number, balance, account_holder):
        self.account_number = account_number
        self.balance = balance
        self.account_holder = account_holder

    def deposit(self, amount):
        self.balance += amount

    def withdraw(self, amount):
        if amount > self.balance:
            print("Insufficient funds.")
        else:
            self.balance -= amount

    def get_balance(self):
        return self.balance


class CheckingAccount(BankAccount):
    def __init__(self, account_number, balance, account_holder, transaction_fees):
        super().__init__(account_number, balance, account_holder)
        self.transaction_fees = transaction_fees

    def apply_transaction_fees(self):
        self.balance -= self.transaction_fees


class SavingsAccount(BankAccount):
    def __init__(self, account_number, balance, account_holder, interest_rate):
        super().__init__(account_number, balance, account_holder)
        self.interest_rate = interest_rate

    def calculate_interest(self):
        interest = self.balance * self.interest_rate
        self.balance += interest
#Here's how you can create instances of these classes and call the specified methods:

# create BankAccount object
account = BankAccount(567890, 1000, "Akshitha")
account.deposit(200)
account.withdraw(700)
#print("The total Bank account balance: ", account.get_balance())

# create CheckingAccount object
checking_account = CheckingAccount(567890, 1000, "Akshitha", 34.50)
checking_account.deposit(200)
checking_account.withdraw(700)
checking_account.apply_transaction_fees()
#print("The total checking account balance: ",checking_account.get_balance())

# create SavingsAccount object
savings_account = SavingsAccount(567890, 1000, "Akshitha", 0.12)
savings_account.deposit(200)
savings_account.withdraw(700)
savings_account.calculate_interest()
print("The total savings account balance: ",savings_account.get_balance())
