# UCID:at892
# Name: Akshitha Thumma
# Date of submission :02-26-2023 
arr1 = [-10, 20, -30, 40, -50, 60, -70, 80, -90, 100] #1
arr2 = [5, -8, 13, -21, 34, -55, 89, -144, 233] #2 
arr3 = [-7, 12, -15, 18, -21, 24, -27, 30, -33] #3
arr4 = [11, -22, 33, -44, 55, -66, 77, -88, 99] #4
arr5 = [-3, 6, -9, 12, -15, 18, -21, 24, -27, 30] #5

# Convert the negative values in the following lists to positive and output the sum of all values (print the output for all lists).
def converted_sum_values(num, arr): # pass the num as list number and arr as list name
    print(f'output for arr {num} : \n')
    total = 0
    for i in range(len(arr)):
        if arr[i] < 0:
            arr[i] = -arr[i]  # convert negative values to positive
        total += arr[i]
    print(f'Sum of all values: {total}')

    

converted_sum_values(1, arr1)
converted_sum_values(2, arr2)
converted_sum_values(3, arr3)
converted_sum_values(4, arr4)
converted_sum_values(5, arr5)
print('\n End of converted sum values')


