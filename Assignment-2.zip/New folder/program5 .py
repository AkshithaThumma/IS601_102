# UCID:at892
# Name: Akshitha Thumma
# Date of submission :02-26-2023 
def print_smallest_value(my_list):
    min_value = min(my_list)
    print("The smallest value in the list is:", min_value)
my_list = [2,4,6,7,9]
print_smallest_value(my_list)