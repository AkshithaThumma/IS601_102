from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from .models import Project

def home(request):
    return render(request, 'home.html', {'name': 'Your Name', 'photo_url': 'https://example.com/photo.jpg', 'email': 'your.email@example.com', 'github': 'https://github.com/AkshithaThumma'})

def portfolio(request):
    projects = Project.objects.all()
    return render(request, 'portfolio.html', {'projects': projects})

def about(request):
    return render(request, 'about.html', {'bio': 'Hello, Im Akshitha Thumma, a Computer Science and Engineering graduate with a passion for innovation and creativity. I am always eager to explore new ideas and implement them with enthusiasm. I have a natural ability to learn quickly and adapt to different circumstances, which has helped me excel in various projects and endeavors. I am committed to constantly improving myself and my skills, and I strive to stay up-to-date with the latest technologies and trends in my field.'})
